# Kodular TinyWebDB Service

A web DB service that stores and retrieves values for a Kodular app.

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template/qXPej_?referralCode=N1BVB_) [![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy?template=https://github.com/pavi2410/TinyWebDB)

Built on top of [Flask](http://flask.pocoo.org/) micro-framework, and supports hosting on [Heroku](https://www.heroku.com/) and other hosts.
